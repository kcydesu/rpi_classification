# rpi_classification
Implementation of PyTorch on Raspberry Pi.
